import vercelApp from "../src/vercel.js";

export const config = {
  runtime: "edge",
};

export default vercelApp;
